package net.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBOpen {

    //DB 연결 메소드
    public Connection getConnection() {
        Connection con=null;
        try {     

            //로컬
            String url     ="jdbc:mariadb://localhost:3306/testdb";
            String user    ="root";
            String password="root";
            String driver  ="org.mariadb.jdbc.Driver"; 
            Class.forName(driver);
            con=DriverManager.getConnection(url, user, password);
         
        }catch (Exception e) {
            System.out.println("mariaDB연결 실패:" + e);
        }//end
        
        return con;
        
    }//getConnection() end
    
}//class end
