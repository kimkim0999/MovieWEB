package kr.co.studycafe.reserve;

public class CalendarDTO {
	private int nowYear;
	private int nowMonth;
	private int nowDate;
	private int start;
	private int calTot;
	
	public int getNowYear() {
		return nowYear;
	}
	public void setNowYear(int nowYear) {
		this.nowYear = nowYear;
	}
	public int getNowMonth() {
		return nowMonth;
	}
	public void setNowMonth(int nowMonth) {
		this.nowMonth = nowMonth;
	}
	public int getNowDate() {
		return nowDate;
	}
	public void setNowDate(int nowDate) {
		this.nowDate = nowDate;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getCalTot() {
		return calTot;
	}
	public void setCalTot(int calTot) {
		this.calTot = calTot;
	}

	
	
}
