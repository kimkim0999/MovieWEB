package kr.co.studycafe;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;



@SpringBootApplication
public class SSolStudyCafeApplication extends SpringBootServletInitializer {
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder Application) {
		return Application.sources(SSolStudyCafeApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(SSolStudyCafeApplication.class, args);
	}

}
