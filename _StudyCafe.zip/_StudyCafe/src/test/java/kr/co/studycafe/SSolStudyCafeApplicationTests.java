package kr.co.studycafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SSolStudyCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
