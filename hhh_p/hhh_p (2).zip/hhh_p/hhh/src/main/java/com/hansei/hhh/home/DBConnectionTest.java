package com.hansei.hhh.home;

import java.sql.*;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class DBConnectionTest {
    public static void main(String[] args) throws Exception {
    	
        ApplicationContext ac = new GenericXmlApplicationContext("file:src/main/webapp/WEB-INF/spring/**/root-context.xml");
        DataSource ds = ac.getBean(DataSource.class);

        Connection conn = ds.getConnection(); // �����ͺ��̽��� ������ ��´�.

        System.out.println("conn = " + conn);
        System.out.println("??");
        //assertTrue(conn!=null);
    } // main()
}

