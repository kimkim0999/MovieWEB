package com.hansei.hhh.home;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

public class UserDao {
	
	/*
	 * @Autowired SqlSession session;
	 * 
	 * String namespace = "com.hansei.hhh.userMapper.";
	 * 
	 * //userMapper ���� ���� �޴´� UserDto select(String user_id) throws Exception{
	 * return session.selectOne(namespace+"select", user_id); }
	 */
}
