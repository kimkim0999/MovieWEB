package com.hansei.hhh.home;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserService {
	
	/*
	 * @Autowired UserDao userdao;
	 * 
	 * public UserDto select(String user_id) throws Exception{ return
	 * userdao.select(user_id); }
	 */
	
}
